$( document ).ready(function(){
    $( ".recent_heading button").click(function() {
        $(".inbox_chat").toggle( "slow" );
    });
});